"""
`client.py`:

Functions:
1. set_exp(exp_name: str) -> Any:
2. load_model(model_uri: str) -> Any:
3. spark_udf(
        spark,
        model_uri: str,
        result_type: str = 'double',
        env_manager: str = 'local',
    ) -> Any:

Classes & Methods:
MLClient
1. set_model_tags(self, run_id):
2. search_runs(self, exp_id: str):
3. register_model(self, model_name: str, run_id: str) -> Any:
4. change_stage(self, model_name: str, ver_list: List[str], stage: str) -> Any:
5. model_versions(self, model_name: str) -> Any:
6. log_data(self, prun_id: str, data_obj, location: str) -> None:
7. delete_model_version(self, model_name: str, ver_list: List[str]) -> Any:
8. delete_reg_model(self, model_name: str):
9. delete_run_by_id(self, run_ids: List[Any]) -> Any:
10. version(self) -> str:


`classification.py`:
Classes & Methods:
Classifier
1. eval_metrics(self, actual, pred):
2. model_fit_log(self, model, run_name: str) -> None:
3. LogisticRegression(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
4. RandomForestClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
5. AdaBoostClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
6. GradientBoostingClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
7. CatBoostClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
8. LGBMClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
9. XGBClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
10. DecisionTreeClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
11. SupportVectorClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
12. RidgeClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
13. KNeighborsClassifier(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
14. GaussianNB(
        self,
        is_tune=False,
        params: Optional[Dict[Any, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:


`regression.py`:
Classes & Methods:
Regressor
1. eval_metrics(self, actual, pred) -> Tuple[Any, Any, Any, Any, float]:
2. model_fit_log(self, model: Any, run_name: str) -> None:
3. LinearRegression(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
4. RidgeRegression(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
5. LassoRegression(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
6. ElasticNet(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
7. SupportVectorRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
8. KNNRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
9. RandomForestRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
10. XGBRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
11. CatBoostRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
12. LGBMRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
13. GradientBoostingRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
14. AdaBoostRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
15. DecisionTreeRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:
16. ExtraTreeRegressor(
        self,
        is_tune=False,
        params: Optional[Dict[str, Any]] = None,
        n_trials: int = 5,
        **kwargs,
    ) -> None:


`hyperparameter_tuning.py`:

Classes & Methods:
HyperParameterTune
1. eval_metrics_classification(self, actual, pred):
2. model_fit_log_classification(self, params: Dict[Any, Any]) -> Any:
3. eval_metrics_regression(
        self,
        actual,
        pred,
    ) -> Tuple[Any, Any, Any, Any, float]:
4. model_fit_log_regression(self, params: Dict[Any, Any]) -> float:
5. generate_hyperparameter(self, trial):
6. objective(self, trial):
7. tune(self, model, run_name: str, n_trials: int):
"""